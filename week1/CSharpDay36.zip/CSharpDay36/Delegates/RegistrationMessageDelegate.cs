public delegate void RegistrationMessageDelegate(string mesage);
